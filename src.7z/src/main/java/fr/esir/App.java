package fr.esir;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        //Ca commence ici
        System.out.println( "Hello World!" );
        //Ca termine ici
    }
}
